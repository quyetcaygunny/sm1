var config = {
    map: {
        '*': {
            cpowlcarousel: 'SM_SU/js/owl.carousel',
        }
    }
};
