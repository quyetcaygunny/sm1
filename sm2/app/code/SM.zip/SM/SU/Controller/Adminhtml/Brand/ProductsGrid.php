<?php

namespace SM\SU\Controller\Adminhtml\Brand;

class ProductsGrid extends Products
{
}
