var config = {
    map: {
        '*': {
            cpowlcarousel: 'SM_SU/js/owl.carousel',
            mpDevbridgeAutocomplete:'SM_SU/js/jquery.autocomplete',
            boostrap: "SM_SU/js/bootstrap.min",
        }
    }
};
